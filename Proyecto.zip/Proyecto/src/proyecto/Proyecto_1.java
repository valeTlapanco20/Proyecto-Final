
package proyecto;

/**
 *
 * @author ioann
 */
public class Proyecto_1 {
    private int desayuno;
    private int comida;
    private int cena;
    private int bebidas;
    private int refrescos; 
    private int postres;
    private int platillos;
    private int opcion;
    private float suma;
    private float suma2;
    private float sumatotal; 
    
    
    public Proyecto_1 (){}

    public Proyecto_1(int desayuno, int comida, int cena, int bebidas, int refrescos,int postres, int platillos,int opcion, float suma, float suma2, float sumatotal) {
        this.desayuno = desayuno;
        this.comida = comida;
        this.cena = cena;
        this.bebidas = bebidas;
        this.refrescos = refrescos;
        this.postres = postres;
        this.platillos = platillos;
        this.opcion = opcion;
        this.suma = suma;
        this.suma2 = suma2;
        this.sumatotal = sumatotal;
    }

    public float getSumatotal() {
        return sumatotal;
    }

    public void setSumatotal(float sumatotal) {
        this.sumatotal = sumatotal;
    }

    public int getDesayuno() {
        return desayuno;
    }

    public void setDesayuno(int desayuno) {
        this.desayuno = desayuno;
    }

    public int getComida() {
        return comida;
    }

    public void setComida(int comida) {
        this.comida = comida;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public int getBebidas() {
        return bebidas;
    }

    public void setBebidas(int bebidas) {
        this.bebidas = bebidas;
    }

    public int getRefrescos() {
        return refrescos;
    }

    public void setRefrescos(int refrescos) {
        this.refrescos = refrescos;
    }
    

    public int getPlatillos() {
        return platillos;
    }

    public void setPlatillos(int platillos) {
        this.platillos = platillos;
    }
    

    public float getSuma() {
        return suma;
    }

    public void setSuma(float suma) {
        this.suma = suma;
    }

    public float getSuma2() {
        return suma2;
    }

    public void setSuma2(float suma2) {
        this.suma2 = suma2;
    }

    public int getOpcion() {
        return opcion;
    }

    public void setOpcion(int opcion) {
        this.opcion = opcion;
    }

    public int getPostres() {
        return postres;
    }

    public void setPostres(int postres) {
        this.postres = postres;
    }

    @Override
    public String toString() {
        return "el total por los productos es total " + suma + "favor de pagar al cajero";
    }
    
    
    
}
