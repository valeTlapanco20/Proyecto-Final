
package proyecto;

/**
 *
 * @author ioann
 */
import java.util.Scanner;
public class Proyecto {

  
    public static void main(String[] args) {
        Scanner obj=new Scanner (System.in);
        int menu;
         do {
             System.out.println("bienvenidos a el restaurante  HUEVOS PELUDOS    ");
             System.out.println("por favor inserte que menu desea escoger ");
             System.out.println("1.desayuno " + "\n2. comida " + "\n3.cena " + "\n4.bebidas" + "\n5.postres" + "\n6.salir");
             menu =obj.nextInt();

            switch (menu) {
                case 1:
                   caso_1 ();
                    break;
                case 2:
                    caso_2 ();
                    break;
                case 3:
                    caso_3 ();            
                    break;

                case 4:
                   caso_4 ();
                    break;
                case 5:
                   caso_5 ();
                    break;
                case 6:
                    System.out.println("gracias por participar");
                    break;
                default:
                    System.out.println("favor de elegir un caso correctamente");   
            }

        } while (menu != 6);

    }
    
    
    
    public static void caso_1(){
        Scanner obj=new Scanner (System.in);
        Proyecto_1 i=new Proyecto_1 ();
        int desayuno;
        int platillos;
        float suma ;
        float suma2;
        float sumatotal;
        System.out.println("bienvenido , por favor elija los siguieentes ingredientes");
        System.out.println("1.huevos con tocino=50$" + "\n2.chilaquiles=60$" + "\n3.moyetes=40$" + "\n4.coctel de frutas=70$");
        desayuno =obj.nextInt();
        switch (desayuno ){
            case 1:
                System.out.println("favor de elegir cuantos platillos desea ");
                platillos=obj.nextInt();
                i.setPlatillos(platillos);
                suma =50 *platillos;
                i.setSuma(suma);
                 if (suma>=300){
                  suma2=(suma*10)/100;
                  i.setSuma2(suma2);
                  sumatotal=suma-suma2;
                  i.setSumatotal(sumatotal);
                  System.out.println("la suma total de los productos con el descuento es " + sumatotal + "\nfavor de pagar al cajero");
                }
                else{
                     System.out.println(i.toString());
                 }
            break;
            case 2:
                System.out.println("favor de elegir cuantos platillos desea ");
                platillos=obj.nextInt();
                i.setPlatillos(platillos);
                suma =60 *platillos;
                i.setSuma(suma);
                 if (suma>=300){
                  suma2=(suma*10)/100;
                  i.setSuma2(suma2);
                  sumatotal=suma-suma2;
                  i.setSumatotal(sumatotal);
                  System.out.println("la suma total de los productos con el descuento es " + sumatotal + "\nfavor de pagar al cajero");
                }
                else{
                     System.out.println(i.toString());
                }
            break;
            case 3:
                System.out.println("favor de elegir cuantos platillos desea ");
                platillos=obj.nextInt();
                i.setPlatillos(platillos);
                suma =40 *platillos;
                i.setSuma(suma);
                 if (suma>=300){
                  suma2=(suma*10)/100;
                  i.setSuma2(suma2);
                  sumatotal=suma-suma2;
                  i.setSumatotal(sumatotal);
                  System.out.println("la suma total de los productos con el descuento es " + sumatotal + "\nfavor de pagar al cajero");
                }
                else{
                     System.out.println(i.toString());
                }
                
             break;
            case 4:
                System.out.println("favor de elegir cuantos platillos desea ");
                platillos=obj.nextInt();
                suma =70 *platillos;
                i.setSuma(suma);
                 if (suma>=300){
                  suma2=(suma*10)/100;
                  sumatotal=suma-suma2;
                  i.setSumatotal(sumatotal);
                  System.out.println("la suma total de los productos con el descuento es " + sumatotal + "\nfavor de pagar al cajero");
                }
                else{
                     System.out.println(i.toString());
                }
            default :
                System.out.println("por favor ,elija un menu bien optimizado");
        }
}
    public static void caso_2 (){
    Scanner obj=new Scanner (System.in); 
    Proyecto_1 i=new Proyecto_1 ();
    int comida;
    int platillos;
    float suma;
    float suma2;
    float sumatotal;
    System.out.println("1.pozole=60$" + "\n2.tortas =80$" + "\n3.arroz con mole=60$" + "\n4.chiles en hojaldra=80$");
     comida =obj.nextInt();
     i.setComida(comida);
     switch (comida){
         case 1:
             System.out.println("favor de elegir cuantos platilos desee");
             platillos =obj.nextInt();
             suma=60*platillos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 
                 }    
             
            break ;
         case 2:
             System.out.println("favor de elegir cuantos platilos desee");
             platillos =obj.nextInt();
             suma=80*platillos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                System.out.println(i.toString());
                 
                 }    
             
            break ;
         case 3:
             System.out.println("favor de elegir cuantos platilos desee");
             platillos =obj.nextInt();
             suma=60*platillos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 
                 }    
             
            break ;
         case 4:
             System.out.println("favor de elegir cuantos platilos desee");
             platillos =obj.nextInt();
             suma=80*platillos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 
                 }    
             
            break ;
         default :
             System.out.println("favro de elegir correctamente la opcion ");
             
     }
             
             
     }
    public static void caso_3 (){
    Scanner obj=new Scanner (System.in);   
    Proyecto_1 i=new Proyecto_1 ();
    int cena;
    int platillos;
    float suma;
    float suma2;
    float sumatotal;
    System.out.println("1.tacos al pastor=15$" + "\n2.pan =5$" + "\n3.maruchan=18$" + "\n4.spagetti=40$");
     cena =obj.nextInt();
     switch (cena){
         case 1:
             System.out.println("favor de elegir cuantos platilos desee");
             platillos =obj.nextInt();
             suma=15*platillos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 }    
             
            break ;
         case 2:
             System.out.println("favor de elegir cuantos platilos desee");
             platillos =obj.nextInt();
             suma=5*platillos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 
                 }    
             
            break ;
         case 3:
             System.out.println("favor de elegir cuantos platilos desee");
             platillos =obj.nextInt();
             suma=18*platillos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 
                 }    
             
            break ;
         case 4:
             System.out.println("favor de elegir cuantos platilos desee");
             platillos =obj.nextInt();
             suma=40*platillos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 
                 }    
             
            break ;
         default :
             System.out.println("favor de elegir la opcion correctamente");
     }
     
    }
    
    public static void caso_4 (){
    Scanner obj=new Scanner (System.in);
    Proyecto_1 i=new Proyecto_1 ();    
    int bebidas;
    int refrescos;
    int opcion;
    float suma;
    float suma2;
    float sumatotal;
    System.out.println("1.Refrescos" + "\n2.cafe" + "\n3.malteadas" + "\n4.te");
     bebidas =obj.nextInt();
      if (bebidas==1 && bebidas ==4 ){
             System.out.println("favor de elegir cuantos bebidas desee");
             refrescos =obj.nextInt();
             i.setRefrescos(refrescos);
             suma=15*refrescos;
             i.setSuma(suma);
             if (suma>=300){
                 suma2=(suma*20)/100;
                 sumatotal=suma-suma2;
                 System.out.println("el total de los productos con el descuento seria de " + suma +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 }
          
      } 
      else {
          System.out.println("favor de elegir el producto correctamente");
      }
           
                     
               
                     
             }
    public static void caso_5 (){
    Scanner obj=new Scanner (System.in);
    Proyecto_1 i=new Proyecto_1 ();
    int postres;
    int platillos;
    float suma;
    float suma2;
    float sumatotal;
    float sumade=0;
    int t=0;
    System.out.println("1.wafles=25$" + "\n2.hotcakes=30$" + "\n3.pastel=25" + "\n4.pay=30$");
     postres =obj.nextInt();
     switch (postres){
         case 1:
             System.out.println("favor de elegir cuantos postres desee");
             platillos =obj.nextInt();
             i.setPlatillos(platillos);
             for (t=0;t<=platillos;t++){
                 
                 sumade=sumade+25;
             }
             suma=sumade;
             i.setSuma(suma);
              if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                  System.out.println(i.toString());
                 
                 }    
             
            break ;
         case 2:
                 System.out.println("favor de elegir cuantos postres desee");
             platillos =obj.nextInt();
             i.setPlatillos(platillos);
             for (t=0;t<=platillos;t++){
                 
                 sumade=sumade+30;
             }
             suma=sumade;
             i.setSuma(suma);
              if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("el total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                 System.out.println(i.toString());
                 
                 }    
             break;
         case 3:
                 System.out.println("favor de elegir cuantos bebidas desee");
             platillos =obj.nextInt();
             i.setPlatillos(platillos);
             for (t=0;t<=platillos;t++){
                 
                 sumade=sumade+25;
                 
             }
             suma=sumade;
             i.setSuma(suma);
              if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("El total de los productos con el descuento seria de " + sumatotal +"\nfavor de pagar al cajero");
                 }
             else {
                 System.out.println(i.toString());
                 
                 }    
              break;
         case 4:
                System.out.println("Favor de elegir cuantos bebidas desee");
             platillos =obj.nextInt();
             i.setPlatillos(platillos);
             for (t=0;t<=platillos;t++){
                 
                 sumade=sumade+30;
             }
             suma=sumade;
             i.setSuma(suma);
              if (suma>=300){
                 suma2=(suma*20)/100;
                 i.setSuma2(suma2);
                 sumatotal=suma-suma2;
                 i.setSumatotal(sumatotal);
                 System.out.println("El total de los productos con el descuento es de " + sumatotal +"\n favor de pagar al cajero");
                 }
             else {
                 System.out.println(i.toString());
                 
                 } 
              break;
         default:
             System.out.println("Favor de elegir un caso fiable");
             
                     
           
             
     }
    
    }
     }
    
    

